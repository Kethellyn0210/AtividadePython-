autonomia_km_por_litro = 12
tanque_litros = 40
distancia_viagem = 450

print("Você precisará reabastecer? ",
       (distancia_viagem / tanque_litros) 
       < autonomia_km_por_litro ) 