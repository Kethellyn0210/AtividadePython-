preco_produto = 45.90
valor_pago = 50.00

print("Troco: ", valor_pago - preco_produto)