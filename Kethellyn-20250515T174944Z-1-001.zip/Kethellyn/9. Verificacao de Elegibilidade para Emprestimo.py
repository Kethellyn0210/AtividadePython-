salario = 3500.00
idade = 22

print("Você pode pegar emprestimo?", salario >= 3000 and idade >= 21)