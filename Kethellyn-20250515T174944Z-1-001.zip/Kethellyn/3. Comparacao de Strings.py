s1 = "Python"
s2 = "Pythonn"

print("Python e igual a Pythonn:", s1==s2)