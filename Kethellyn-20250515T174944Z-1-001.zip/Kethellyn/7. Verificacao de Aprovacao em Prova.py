nota_aluno = 6.5

print("Você foi aprovado?", nota_aluno >= 7.0)