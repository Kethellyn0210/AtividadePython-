velocidade_maxima = 80
velocidade_carro = 85

print("O Carro está acima do limite de velocidade: "
      , velocidade_carro <= velocidade_maxima)