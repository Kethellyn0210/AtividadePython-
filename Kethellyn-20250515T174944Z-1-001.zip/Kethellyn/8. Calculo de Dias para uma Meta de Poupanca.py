meta = 5000
economia_mensal = 200

print("Quantos meses sao necessarios para atingir a meta?",
      meta / economia_mensal)