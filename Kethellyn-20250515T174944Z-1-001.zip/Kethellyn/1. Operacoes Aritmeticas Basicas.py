a = 10
b = 3

print("Soma:", a + b)
print("Subtracao:", a - b)
print("Multiplicacao:", a * b)
print("Divisao:", a / b)