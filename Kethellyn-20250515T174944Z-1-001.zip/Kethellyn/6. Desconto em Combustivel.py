valor_abastecido = 120.00

print("Você recebera desconto?", valor_abastecido > 100.00)